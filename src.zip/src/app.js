
const helpers = require('/opt/helpers');
const axios = require('axios');

exports.handler = async(event)=>{
    const customerId = event.customerId;
    const documentNumber = event.documentNumber;
    const documentType = event.documentType;
    const fullname = event.fullname;
    const private_key = process.env.privateKey;
    console.log( "este es el valor de", process.env.privateKey);
    const vector = process.env.vector;
    const apiSecret = process.env.apiSecret;
    const uri = process.env.uri;
    const appId = process.env.appId;
    const guId = event.guId;
    const apiGeeCretials = process.env.apiGeeCredentials;
    const deviceIp = event.deviceIp;
    const device = event.device;
    const sesion_call = event.sesion_call;
    let responseEnd = '';

    const customerIdEncrypt = helpers.EncryptData(customerId,private_key,vector).data;
    const documentNumberEncrypt = helpers.EncryptData(documentNumber,private_key,vector).data;   
    const fullnameEncrypt = helpers.EncryptData(fullname,private_key,vector).data;

    let bodyToSend=
    {
        "data": {
            "requester": {
                "customerId": customerIdEncrypt,
                "documentNumber": documentNumberEncrypt,
                "documentType": documentType,
                "fullname": fullnameEncrypt
            },
            "costsCenterCode": 8426,
            "lifeTime": 5,
            "recipient": {
                     "transactionalContact": {
                    "notifyToEmail": true,
                    "notifyToCellphone": true
                }
            }
        }
    };
    
    const xguidEncrypt = helpers.EncryptDataMD5(guId);
    const firmaSegmento = helpers.FirmaForPostRequest(appId,xguidEncrypt,bodyToSend.data,apiSecret);
    

    try{

        var config = {
            method: 'post',
            url: uri,
            data: bodyToSend,
            headers: {
                'X-Apigee-Credentials':apiGeeCretials,
                'X-Device-Ip':deviceIp,
                'X-Guid': xguidEncrypt,
                'X-Session': sesion_call,
                'X-Device': device,
                'X-Signature': firmaSegmento                
            }
        };
        console.log(config);

        await axios(config)
        .then(async function (response){
                responseEnd = {
                statusCode: 200,
                data_result : JSON.stringify(response.data)                
            };   

        })
        .catch(function (error) {
            console.error(error);            
            responseEnd = {
                statusCode: 505,
                  error: error
               };                
        });
        
   
    } catch (error) {
        console.error(error);
    }      
    
    return responseEnd;


}